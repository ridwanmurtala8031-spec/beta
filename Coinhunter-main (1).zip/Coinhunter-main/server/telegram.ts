import { groupBindings, signals as signalsTable, users, wallets as walletsTable, trades as tradesTable, userLanes, userPremiums, admins } from "../shared/schema";
import TelegramBot from 'node-telegram-bot-api';
import { storage } from './storage';
import { log } from "./index";
import { Keypair, Connection, PublicKey, Transaction, SystemProgram } from "@solana/web3.js";
import bs58 from "bs58";
import axios from "axios";
import { eq, and, or, count } from "drizzle-orm";
import { db } from "./db";
import { JupiterService } from "./solana";

export let telegramBotInstance: TelegramBot | null = null;

export function getTelegramBot() {
  return telegramBotInstance;
}

export function setupTelegramBot() {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    log("TELEGRAM_BOT_TOKEN is missing. Bot will not start.", "telegram");
    return;
  }

  const rpcUrl = process.env.SOLANA_RPC_URL || "https://api.mainnet-beta.solana.com";
  const jupiter = new JupiterService(rpcUrl);

  log("Initializing Telegram bot...", "telegram");
  
  if (telegramBotInstance) {
    log("Existing bot instance found, stopping polling...", "telegram");
    telegramBotInstance.stopPolling();
  }

  const bot = new TelegramBot(token, { 
    polling: {
      interval: 1000,
      autoStart: true,
      params: {
        timeout: 10
      }
    } 
  }); 
  
  telegramBotInstance = bot;

  const ensureUser = async (msg: TelegramBot.Message) => {
    const id = msg.from?.id.toString();
    if (!id) return null;
    const existingUser = await storage.getUser(id);
    if (existingUser) return existingUser;

    const user = await storage.upsertUser({
      id,
      username: msg.from?.username || null,
      firstName: msg.from?.first_name || null,
      isMainnet: true
    });

    // Check if user already has wallets before creating a new one
    const existingWallets = await storage.getWallets(id);
    if (existingWallets.length === 0) {
      const keypair = Keypair.generate();
      await storage.createWallet({
        userId: id,
        publicKey: keypair.publicKey.toString(),
        privateKey: bs58.encode(keypair.secretKey),
        label: "Main Wallet",
        isMainnet: true,
        isActive: true,
        balance: "0"
      });
    }

    return user;
  };

  // Ensure a userPremium row exists (free tier) for usage tracking
  const ensureUserPremiumRow = async (userId: string) => {
    const p = await storage.getUserPremium(userId);
    if (!p) {
      // create free tier entry
      const expiresAt = 0;
      await storage.upsertUserPremium({ userId, tier: 'free', expiresAt });
    }
  };

  const OWNER_ID = '6491714705';

  async function isPremiumOrAdmin(userId: string): Promise<boolean> {
    try {
      if (!userId) return false;
      if (userId === OWNER_ID) return true;
      const admin = await storage.isAdmin(userId);
      if (admin) return true;
      const p = await storage.getUserPremium(userId);
      if (!p) return false;
      if (p.tier && p.tier !== 'free' && p.expiresAt && p.expiresAt > Date.now()) return true;
      return false;
    } catch (e) { return false; }
  }

  // Check and consume usage. Returns true if allowed, false if blocked (message sent to user)
  async function checkAndConsumeUsage(userId: string, type: 'analyze' | 'other', chatId: number): Promise<boolean> {
    try {
      await storage.resetDailyUsageIfNeeded(userId);
      const p = await storage.getUserPremium(userId);
      if (!p) {
        await ensureUserPremiumRow(userId);
        return true;
      }

      // If user has a premium tier and not expired, allow
      const now = Date.now();
      if (p.tier && p.tier !== 'free' && p.expiresAt && p.expiresAt > now) return true;

      // Free tier: allow 2 analyze and 2 other per day
      const analyzeUsed = p.dailyAnalyzeUsage || 0;
      const otherUsed = p.dailyOtherUsage || 0;

      if (type === 'analyze') {
        if (analyzeUsed >= 2) {
          await promptSubscribe(chatId, userId);
          return false;
        }
      } else {
        if (otherUsed >= 2) {
          await promptSubscribe(chatId, userId);
          return false;
        }
      }

      await storage.incrementDailyUsage(userId, type);
      return true;
    } catch (e: any) {
      log(`Usage check error: ${e.message}`, "telegram");
      return true;
    }
  }

  const PAYMENT_WALLET = process.env.PAYMENT_WALLET || '';

  async function getSolForUsd(usd: number): Promise<{ sol: number; lamports: number }> {
    try {
      const res = await axios.get('https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd');
      const price = res.data?.solana?.usd;
      if (!price || price <= 0) throw new Error('Failed to fetch SOL price');
      const sol = +(usd / price).toFixed(6);
      const lamports = Math.ceil(sol * 1e9);
      return { sol, lamports };
    } catch (e) {
      throw new Error('Price oracle error');
    }
  }

  async function promptSubscribe(chatId: number, userId: string) {
    const keyboard = [
      [{ text: "$25 / 1w", callback_data: `subscribe:25:7` }, { text: "$50 / 2w", callback_data: `subscribe:50:14` }],
      [{ text: "$75 / 3w", callback_data: `subscribe:75:21` }, { text: "$100 / 1m", callback_data: `subscribe:100:30` }]
    ];
    const msg = `⚠️ <b>Daily Limit Reached</b>\n\nYou have reached the free daily usage limit. Subscribe to Premium to continue using premium analysis and unlimited scans. Choose a tier below to pay via Solana transaction.`;
    bot.sendMessage(chatId, msg, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
  }

  // Verify transaction signature sent by user to grant premium
  async function verifyTransactionAndGrant(userId: string, signature: string, expectedLamports: number, tierDays: number, chatId?: number) {
    try {
      if (!PAYMENT_WALLET) {
        bot.sendMessage(chatId || Number(userId), "❌ Payment wallet not configured. Contact admin.");
        return false;
      }
      const connection = new Connection(rpcUrl, 'confirmed');
      const tx = await connection.getTransaction(signature, { commitment: 'confirmed' } as any);
      if (!tx) {
        bot.sendMessage(chatId || Number(userId), "❌ Transaction not found or not yet confirmed. Ensure it's on Solana mainnet and confirmed.");
        return false;
      }

      // Determine amount received by PAYMENT_WALLET via balance diffs
      const accountKeys = tx.transaction.message.accountKeys.map((k: any) => (k?.toString ? k.toString() : String(k)));
      const idx = accountKeys.indexOf(PAYMENT_WALLET);
      if (idx === -1 || !tx.meta || !Array.isArray(tx.meta.preBalances) || !Array.isArray(tx.meta.postBalances)) {
        bot.sendMessage(chatId || Number(userId), "❌ Transaction does not include the payment wallet or lacks balance info.");
        return false;
      }
      const received = (tx.meta.postBalances[idx] || 0) - (tx.meta.preBalances[idx] || 0);
      // Allow 0.5% tolerance
      const minRequired = Math.floor(expectedLamports * 0.995);
      log(`Payment verify: signature=${signature} received=${received} lamports, expected=${expectedLamports}, minRequired=${minRequired}`, "telegram");
      if (received < minRequired) {
        bot.sendMessage(chatId || Number(userId), `❌ Insufficient payment. Detected ${(received/1e9).toFixed(6)} SOL received but expected ${(expectedLamports/1e9).toFixed(6)} SOL (or equivalent).`);
        return false;
      }

      // Check for memo instruction (support common memo program ids)
      const memoPrograms = [
        'MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr',
        'Memo111111111111111111111111111111111111111'
      ];
      let memoFound = false;
      try {
        const instrs = tx.transaction.message.instructions || [];
        for (const ins of instrs) {
          const pid = (ins.programId?.toString && ins.programId.toString()) || ins.programId || ins.program || '';
          if (memoPrograms.includes(pid)) {
            const data = ins.data || ins.parsed || '';
            const raw = typeof data === 'string' ? data : JSON.stringify(data);
            const pending = (subscriptionPending as any)[userId];
            if (pending?.ref && raw.includes(pending.ref)) memoFound = true;
          }
        }
        // Check innerInstructions too
        if (!memoFound && tx.meta && Array.isArray(tx.meta.innerInstructions)) {
          for (const inner of tx.meta.innerInstructions) {
            for (const ins of inner.instructions || []) {
              const pid = (ins.programId?.toString && ins.programId.toString()) || ins.programId || ins.program || '';
              if (memoPrograms.includes(pid)) {
                const data = ins.data || ins.parsed || '';
                const raw = typeof data === 'string' ? data : JSON.stringify(data);
                const pending = (subscriptionPending as any)[userId];
                if (pending?.ref && raw.includes(pending.ref)) memoFound = true;
              }
            }
          }
        }
      } catch (e) {
        // ignore memo parse errors
      }

      // If a memo reference was generated for this user, ensure it's present in the transaction
      try {
        const pending = (subscriptionPending as any)[userId];
        if (pending?.ref && !memoFound) {
          // fallback: stringify tx and search
          const rawTx = JSON.stringify(tx);
          const containsRef = rawTx.includes(pending.ref);
          if (!containsRef) {
            // Allow activation if amount matches (fall back to amount-only verification)
            if (received >= minRequired) {
              bot.sendMessage(chatId || Number(userId), `⚠️ Payment verified by amount but memo reference <b>${pending.ref}</b> was not detected in the transaction. Activating premium as amount matches. For automated verification please include the memo in future payments.`, { parse_mode: 'HTML' });
              // proceed without returning false
            } else {
              bot.sendMessage(chatId || Number(userId), `❌ Payment found, but memo reference <b>${pending.ref}</b> was not detected in the transaction. Please include the reference in the memo field and try again.`, { parse_mode: 'HTML' });
              return false;
            }
          }
        }
      } catch (e) {
        // ignore memo check failures
      }

      // If a memo reference was generated for this user, ensure it's present in the transaction
      try {
        const pending = (subscriptionPending as any)[userId];
        if (pending?.ref) {
          const rawTx = JSON.stringify(tx);
          if (!rawTx.includes(pending.ref)) {
            bot.sendMessage(chatId || Number(userId), `❌ Payment found, but memo reference <b>${pending.ref}</b> was not detected in the transaction. Please include the reference in the memo field and try again.`, { parse_mode: 'HTML' });
            return false;
          }
        }
      } catch (e) {
        // ignore memo check failures
      }

      // Grant premium: set expiry based on now + tierDays
      const expiresAt = Date.now() + (tierDays * 24 * 60 * 60 * 1000);
      await storage.upsertUserPremium({ userId, tier: `paid_${tierDays}d`, expiresAt });
      bot.sendMessage(chatId || Number(userId), `✅ Payment verified. Premium activated for ${tierDays} days. Expires: ${new Date(expiresAt).toLocaleString()}` , { parse_mode: 'HTML' });
      return true;
    } catch (e: any) {
      log(`Payment verify error: ${e.message}`, "telegram");
      bot.sendMessage(chatId || Number(userId), `❌ Error verifying transaction: ${e.message}`);
      return false;
    }
  }

  // Periodic checker for expiring premiums (runs every 6 hours)
  setInterval(async () => {
    try {
      const soon = Date.now() + (2 * 24 * 60 * 60 * 1000); // 2 days
      // Query premiums expiring within 2 days
      const rows = await db.select().from(userPremiums).where(and(eq(userPremiums.expiresAt, userPremiums.expiresAt), userPremiums.expiresAt.lt(soon as any))).limit(100);
      for (const r of rows) {
        if (r.expiresAt && r.expiresAt > Date.now()) {
          // send reminder to user id
          try { await bot.sendMessage(Number(r.userId), `⏳ Reminder: Your premium (${r.tier}) expires on ${new Date(r.expiresAt).toLocaleString()}. Renew to avoid losing premium access. Use /info for subscription details.`); } catch(e){}
        }
      }
    } catch (e: any) {
      log(`Expiry reminder error: ${e.message}`, "telegram");
    }
  }, 6 * 60 * 60 * 1000);

  const executeBuy = async (userId: string, mint: string, amount: string, chatId: number) => {
    bot.sendMessage(chatId, "🚧 <b>Under Construction</b>\n\nTrading and wallet management features are currently under development. Please check back later.", { parse_mode: 'HTML' });
    return;
  };

  const executeSell = async (userId: string, mint: string, percent: number, chatId: number) => {
    bot.sendMessage(chatId, "🚧 <b>Under Construction</b>\n\nTrading and wallet management features are currently under development. Please check back later.", { parse_mode: 'HTML' });
    return;
  };

  const sendBuyAmountMenu = async (chatId: number, mint: string) => {
    bot.sendMessage(chatId, "🚧 <b>Under Construction</b>\n\nTrading and wallet management features are currently under development. Please check back later.", { parse_mode: 'HTML' });
  };

  const sendTokenOverview = async (chatId: number, mint: string, messageId?: number, threadId?: number) => {
    try {
      const response = await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${mint}`);
      const data = response.data as any;
      const pair = data.pairs?.[0];

      if (!pair) {
        bot.sendMessage(chatId, "❌ <b>Token not found on DexScreener.</b>", { parse_mode: 'HTML', message_thread_id: threadId });
        return;
      }

      const name = pair.baseToken.name;
      const symbol = pair.baseToken.symbol;
      const price = pair.priceUsd ? `$${parseFloat(pair.priceUsd).toFixed(6)}` : "N/A";
      const mcap = pair.fdv ? `$${pair.fdv.toLocaleString()}` : "N/A";
      const liq = pair.liquidity?.usd ? `$${pair.liquidity.usd.toLocaleString()}` : "N/A";
      const vol = pair.volume?.h24 ? `$${pair.volume.h24.toLocaleString()}` : "N/A";
      const buys = pair.txns?.h24?.buys || 0;
      const sells = pair.txns?.h24?.sells || 0;
      const change = pair.priceChange?.h24 ? `${pair.priceChange.h24 > 0 ? '+' : ''}${pair.priceChange.h24}%` : "0%";

      const message = `🧪 <b>Token Overview</b>\n\n` +
                    `📛 Name: ${name}\n` +
                    `💊 Symbol: $${symbol}\n` +
                    `🔗 Mint: <code>${mint}</code>\n\n` +
                    `📊 <b>Market</b>\n` +
                    `• Price: ${price}\n` +
                    `• Market Cap: ${mcap}\n` +
                    `• Liquidity: ${liq}\n` +
                    `• Volume (24h): ${vol}\n\n` +
                    `📈 <b>Activity (24h)</b>\n` +
                    `• Buys: ${buys}\n` +
                    `• Sells: ${sells}\n` +
                    `• Change: ${change}\n\n` +
                    `🌐 <b>Chart</b>\n` +
                    `https://dexscreener.com/solana/${mint}\n\n` +
                    `⚠️ <i>This is not financial advice.</i>`;

      const keyboard = [
        [{ text: "🛒 Buy (Under Construction)", callback_data: `under_construction` }],
        [{ text: "🤖 AI Analysis", callback_data: `ai_analyze_${mint}` }],
        [{ text: "🔄 Refresh", callback_data: `refresh_overview_${mint}` }]
      ];

      if (messageId) {
        try {
          await bot.editMessageText(message, { chat_id: chatId, message_id: messageId, parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
        } catch (e: any) {
          if (!e.message.includes("message is not modified")) throw e;
        }
      } else {
        bot.sendMessage(chatId, message, { parse_mode: 'HTML', message_thread_id: threadId, reply_markup: { inline_keyboard: keyboard } });
      }
    } catch (e: any) {
      log(`Error fetching token overview: ${e.message}`, "telegram");
      bot.sendMessage(chatId, "❌ <b>Error fetching token data.</b>", { parse_mode: 'HTML' });
    }
  };

  const executeAiReasoning = async (chatId: number, mint: string) => {
    bot.sendMessage(chatId, "🤖 <b>Generating AI Reasoning...</b>", { parse_mode: 'HTML' });
    try {
      const response = await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${mint}`);
      const data = response.data as any;
      const pair = data.pairs?.[0];
      if (!pair) throw new Error("Token data not found.");

      const marketData = JSON.stringify({
        name: pair.baseToken.name,
        symbol: pair.baseToken.symbol,
        price: pair.priceUsd,
        fdv: pair.fdv,
        liquidity: pair.liquidity?.usd,
        volume24h: pair.volume?.h24,
        txns24h: pair.txns?.h24,
        priceChange24h: pair.priceChange?.h24
      });

      const { openRouterClient } = await import("./signals-worker");
      if (!openRouterClient) throw new Error("AI Client not initialized.");

      const aiResponse = await (openRouterClient as any).chat.completions.create({
        model: "google/gemini-2.0-flash-001",
        messages: [
          {
            role: "system",
            content: `You are an expert Solana token analyst. Analyze the following market data and provide reasoning in this EXACT format:
🤖 AI Token Reasoning

📛 [NAME] ($[SYMBOL])

🔐 Liquidity Analysis
• Liquidity: $[LIQUIDITY]
• LP Status: [Locked/Healthy/Risky based on data]

📊 Market Structure
• Market Cap (FDV): $[FDV]
• Volume (24h): $[VOLUME]

📈 Behavior
• Buys: [BUYS]
• Sells: [SELLS]
• Bias: [Bullish/Bearish Bias]

🧮 Risk Score
• Score: [X]/10

🚩 Rug-Risk Flags
• [Brief red flags or "No major red flags"]

[2-3 sentence short/brief insight on the token's potential and current momentum]

⚠️ This is probabilistic analysis, not financial advice.`
          },
          { role: "user", content: `Analyze this token: ${marketData}` }
        ]
      });

      const reasoning = aiResponse.choices[0].message.content;
      bot.sendMessage(chatId, reasoning, { parse_mode: 'HTML' });
    } catch (e: any) {
      log(`AI reasoning error: ${e.message}`, "telegram");
      bot.sendMessage(chatId, `❌ <b>AI Reasoning Failed:</b> ${e.message}`, { parse_mode: 'HTML' });
    }
  };

  // In-memory pending subscription map: userId -> { lamports, days, ref }
  const subscriptionPending: Record<string, { lamports: number; days: number; ref?: string }> = {};

  async function sendMainMenu(chatId: number, userId: string, messageId?: number) {
    const activeWallet = await storage.getActiveWallet(userId);
    let balance = "0.000";
    
    if (activeWallet) {
      try {
        const connection = new Connection(rpcUrl, "confirmed");
        const bal = await connection.getBalance(new PublicKey(activeWallet.publicKey));
        balance = (bal / 1e9).toFixed(3);
        await storage.updateWalletBalance(activeWallet.id, balance);
      } catch (e) {
        log(`Failed to fetch real-time balance for ${activeWallet.publicKey}: ${e}`, "telegram");
        balance = activeWallet.balance || "0.000";
      }
    }

    const header = `🚀 <b>Welcome to Coin Hunter Bot</b>\n\n` +
                   `The most advanced Smart Money Concepts trading terminal on Solana.\n\n` +
                   `Wallet: <code>${activeWallet?.publicKey || 'None'}</code> (Tap to copy)\n` +
                   `Active Balance: <b>${balance} SOL</b>\n\n` +
                   `Quick Commands:\n` +
                   `• /buy [mint] [amount] - Manual Buy\n` +
                   `• /sell [mint] [percent] - Manual Sell\n` +
                   `• /settings - Configure Bot\n` +
                   `• /withdraw - Withdraw SOL\n` +
                   `• /history - View trade history`;

    const keyboard = [
      [{ text: "🔄 Refresh", callback_data: "main_menu_refresh" }],
      [{ text: "🛒 Buy (Under Construction)", callback_data: "under_construction" }, { text: "💰 Sell (Under Construction)", callback_data: "under_construction" }],
      [{ text: "📂 Positions (Under Construction)", callback_data: "under_construction" }, { text: "📜 History", callback_data: "menu_history" }],
      [{ text: "💸 Withdraw", callback_data: "menu_withdraw" }, { text: "⚙️ Settings", callback_data: "menu_settings" }]
    ];
    if (messageId) {
      try {
        await bot.editMessageText(header, { chat_id: chatId, message_id: messageId, parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
      } catch (e: any) {
        if (!e.message.includes("message is not modified")) throw e;
      }
    } else {
      bot.sendMessage(chatId, header, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
    }
  }

  bot.on('message', async (msg) => {
    log(`Received message from ${msg.from?.username} (${msg.from?.id}): ${msg.text}`, "telegram");
    const chatId = msg.chat.id;
    const userId = msg.from?.id?.toString();
    if (!userId) return;

    const now = Math.floor(Date.now() / 1000);
    if (msg.date && (now - msg.date > 30)) return;

    try {
      await ensureUser(msg);
      await ensureUserPremiumRow(msg.from!.id.toString());
      const isPrivate = msg.chat.type === 'private';

      // Restrict commands for non-premium users: only /analyze and /setup allowed
      if (msg.text && msg.text.startsWith('/')) {
        const cmd = msg.text.split(' ')[0].toLowerCase();
        const allowedForFree = ['/analyze', '/setup'];
        const isAllowed = allowedForFree.includes(cmd);
        const privileged = await isPremiumOrAdmin(userId);
        if (!privileged && !isAllowed) {
          bot.sendMessage(chatId, `🔒 This command is available to Premium users only. Use /analyze or /setup as a free user.\n\nContact: @shiller_xxx or @FiftyOneP3rcent`, { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
          return;
        }
      }

      // Check for AI lane restriction in groups
      const checkAiLane = async () => {
        if (isPrivate) return true;
        
        // Find if there is ANY AI binding for this group
        const aiBinding = await db.select().from(groupBindings).where(
          and(
            eq(groupBindings.groupId, chatId.toString()),
            eq(groupBindings.market, "ai")
          )
        ).limit(1);
        
        if (aiBinding.length === 0) {
          // If no AI lane is bound at all to this group, we shouldn't respond to AI commands in this group
          log(`AI command blocked: Group ${chatId} has no AI lane bound.`, "telegram");
          return false;
        }
        
        const currentTopic = msg.message_thread_id?.toString() || null;
        // If the AI market is bound to a specific topic, restrict commands strictly to it
        if (aiBinding[0].topicId !== currentTopic) {
          bot.sendMessage(chatId, `⚠️ <b>Action Restricted</b>\n\nPlease use the designated <b>AI Analysis</b> topic for this request.`, { 
            parse_mode: 'HTML', 
            message_thread_id: msg.message_thread_id 
          });
          return false;
        }
        return true;
      };

      // Define /ai command
      if (msg.text?.startsWith('/ai ')) {
        if (!(await checkAiLane())) return;
        // Enforce free tier usage for AI (count as 'other')
        const allowed = await checkAndConsumeUsage(msg.from!.id.toString(), 'other', chatId);
        if (!allowed) return;
        const query = msg.text.slice(4).trim();
        if (!query) {
          bot.sendMessage(chatId, "❌ Please provide a query, e.g. <code>/ai Analyze BTC sentiment</code>", { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
          return;
        }

        bot.sendMessage(chatId, "🤖 <b>Processing AI Request...</b>", { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
        const { openRouterClient } = await import("./signals-worker");
        if (!openRouterClient) {
          bot.sendMessage(chatId, "❌ AI service not initialized.", { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
          return;
        }

        try {
          const response = await openRouterClient.chat.completions.create({
            model: "google/gemini-2.0-flash-001",
            messages: [
              { role: "system", content: "You are a crypto and web3 expert. ANSWER ONLY: trading strategies, crypto, blockchain, web3, DeFi, NFTs, meme coins, solana, forex, market analysis. CRITICAL: Keep answers SHORT (5-7 sentences max). Be direct and precise. NO stories, NO fluff. If not crypto/trading/web3: respond 'REFUSE'." },
              { role: "user", content: query }
            ]
          });
          const aiResponse = response.choices[0].message?.content || "No response.";
          if (aiResponse.startsWith('REFUSE')) {
            bot.sendMessage(chatId, "❌ That question is outside my expertise. Please ask about crypto, web3, solana, trading, or DeFi.", { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
          } else {
            // Split response if too long (Telegram limit is 4096 chars)
            const maxLength = 4000;
            if (aiResponse.length > maxLength) {
              const chunks = [];
              let currentChunk = '';
              const paragraphs = aiResponse.split('\n');
              
              for (const para of paragraphs) {
                if ((currentChunk + para + '\n').length > maxLength) {
                  if (currentChunk) chunks.push(currentChunk.trim());
                  currentChunk = para + '\n';
                } else {
                  currentChunk += para + '\n';
                }
              }
              if (currentChunk) chunks.push(currentChunk.trim());
              
              // Send all chunks
              for (let i = 0; i < chunks.length; i++) {
                const chunk = chunks[i];
                const prefix = chunks.length > 1 ? `<b>Part ${i + 1}/${chunks.length}</b>\n\n` : '';
                bot.sendMessage(chatId, prefix + chunk, { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
              }
            } else {
              bot.sendMessage(chatId, aiResponse, { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
            }
          }
        } catch (e: any) {
          bot.sendMessage(chatId, `❌ AI Error: ${e.message}`, { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
        }
        return;
      }

      // Admin / Owner commands: /addadmin, /removeadmin, /premium
      if (msg.text?.startsWith('/addadmin') || msg.text?.startsWith('/removeadmin') || msg.text?.startsWith('/premium')) {
        const parts = msg.text.trim().split(/\s+/);
        const cmd = parts[0].toLowerCase();
        const callerId = userId;
        // Only owner can add/remove admins
        if (cmd === '/addadmin' || cmd === '/removeadmin') {
          if (callerId !== OWNER_ID) {
            bot.sendMessage(chatId, '❌ Only the owner can manage admins.', { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
            return;
          }
          const target = parts[1];
          if (!target) {
            bot.sendMessage(chatId, '❌ Usage: /addadmin <userId> or /removeadmin <userId>', { parse_mode: 'HTML' });
            return;
          }
          try {
            if (cmd === '/addadmin') {
              await storage.addAdmin(target, false);
              bot.sendMessage(chatId, `✅ Added admin: ${target}`, { parse_mode: 'HTML' });
            } else {
              await storage.removeAdmin(target);
              bot.sendMessage(chatId, `✅ Removed admin: ${target}`, { parse_mode: 'HTML' });
            }
          } catch (e: any) {
            bot.sendMessage(chatId, `❌ Admin command failed: ${e.message}`);
          }
          return;
        }

        // /premium <userId> <duration>
        if (cmd === '/premium') {
          // Allow owner or admins to grant premium
          const allowed = await isPremiumOrAdmin(callerId!);
          if (!allowed) {
            bot.sendMessage(chatId, '❌ Only owner or admins can grant premium.', { parse_mode: 'HTML' });
            return;
          }
          const target = parts[1];
          const durationRaw = parts[2] || '30d';
          if (!target) {
            bot.sendMessage(chatId, '❌ Usage: /premium <userId> <duration>. Examples: 7d, 2w, 1m', { parse_mode: 'HTML' });
            return;
          }
          // Parse duration
          function parseDuration(s: string): number {
            const lower = s.toLowerCase();
            const m = lower.match(/^(\d+)(d|w|m)?$/);
            if (!m) return 30 * 24 * 60 * 60 * 1000;
            const val = parseInt(m[1], 10);
            const unit = m[2] || 'd';
            if (unit === 'd') return val * 24 * 60 * 60 * 1000;
            if (unit === 'w') return val * 7 * 24 * 60 * 60 * 1000;
            if (unit === 'm') return val * 30 * 24 * 60 * 60 * 1000;
            return val * 24 * 60 * 60 * 1000;
          }
          try {
            const durMs = parseDuration(durationRaw);
            const expiresAt = Date.now() + durMs;
            const days = Math.round(durMs / (24 * 60 * 60 * 1000));
            await storage.upsertUserPremium({ userId: target, tier: `manual_${days}d`, expiresAt });
            bot.sendMessage(chatId, `✅ Granted premium to ${target} for ${days} days. Expires: ${new Date(expiresAt).toLocaleString()}`, { parse_mode: 'HTML' });
          } catch (e: any) {
            bot.sendMessage(chatId, `❌ Failed to grant premium: ${e.message}`);
          }
          return;
        }
      }

      if (msg.text?.startsWith('/premiuminfo')) {
        const caller = userId;
        const allowed = await isPremiumOrAdmin(caller!);
        if (!allowed) {
          bot.sendMessage(chatId, '❌ Only owner or admins can view premium info.', { parse_mode: 'HTML' });
          return;
        }
        const parts = msg.text.trim().split(/\s+/);
        const target = parts[1];
        if (!target) {
          bot.sendMessage(chatId, '❌ Usage: /premiuminfo <userId>', { parse_mode: 'HTML' });
          return;
        }
        try {
          const p = await storage.getUserPremium(target);
          if (!p) {
            bot.sendMessage(chatId, `<b>Premium Info for ${target}</b>\n\nNo premium record found. User is on free tier.`, { parse_mode: 'HTML' });
            return;
          }
          const now = Date.now();
          const isActive = p.expiresAt && p.expiresAt > now;
          const status = isActive ? '✅ ACTIVE' : '❌ EXPIRED';
          const expiryDate = p.expiresAt ? new Date(p.expiresAt).toLocaleString() : 'N/A';
          const createdDate = p.createdAt ? new Date(p.createdAt).toLocaleString() : 'Unknown';
          const daysRemaining = p.expiresAt ? Math.ceil((p.expiresAt - now) / (24*60*60*1000)) : 0;
          const dailyAnalyzeUsed = p.dailyAnalyzeUsage || 0;
          const dailyOtherUsed = p.dailyOtherUsage || 0;
          const info = `<b>Premium Info for ${target}</b>\n\n` +
            `Status: ${status}\n` +
            `Tier: ${p.tier || 'Unknown'}\n` +
            `Created: ${createdDate}\n` +
            `Expires: ${expiryDate}\n` +
            `Days Remaining: ${daysRemaining > 0 ? daysRemaining : 'N/A'}\n\n` +
            `<b>Daily Usage (24h)</b>\n` +
            `Analyzes: ${dailyAnalyzeUsed}/unlimited\n` +
            `Other: ${dailyOtherUsed}/unlimited`;
          bot.sendMessage(chatId, info, { parse_mode: 'HTML' });
        } catch (e: any) {
          bot.sendMessage(chatId, `❌ Failed to fetch premium info: ${e.message}`);
        }
        return;
      }

      if (msg.text === '/admins' || msg.text === '/listadmins') {
        const caller = userId;
        const allowed = await isPremiumOrAdmin(caller!);
        if (!allowed) {
          bot.sendMessage(chatId, '❌ Only owner or admins can view admin list.', { parse_mode: 'HTML' });
          return;
        }
        const adminsList = await db.select().from(admins) as any[];
        if (!adminsList || adminsList.length === 0) {
          bot.sendMessage(chatId, 'No admins configured.', { parse_mode: 'HTML' });
          return;
        }
        const lines = adminsList.map((a: any) => `${a.userId}${a.isOwner ? ' (Owner)' : ''}`);
        const keyboard = adminsList.map((a: any) => [{ text: `Remove ${a.userId}`, callback_data: `admin_remove:${a.userId}` }]);
        bot.sendMessage(chatId, `👥 Admins:\n${lines.join('\n')}`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
        return;
      }

      if (msg.text === '/admincommands' || msg.text === '/commands' || msg.text === '/help') {
        try {
          const part1 = `🏛️ <b>SMC Trading Bot - Command Guide</b>

<b>Core Commands:</b>
• <code>/start</code> - Main dashboard
• <code>/bind [market]</code> - Bind to crypto/forex/ai
• <code>/analyze [pair]</code> - Deep-dive analysis
• <code>/setup [pair]</code> - Neutral setups
• <code>/ai [query]</code> - AI specialist`;
          const part2 = `<b>More Commands:</b>
• <code>/unbind [market]</code> - Unbind signals
• <code>/settings</code> - Configure preferences
• <code>/history</code> - Trade history
• <code>/withdraw</code> - Withdraw SOL

<b>Features:</b> Image analysis, mint address lookup, auto signals every 15m.

<b>Contact:</b> @FiftyOneP3rcent | @shiller_xxx`;
          bot.sendMessage(chatId, part1, { parse_mode: 'HTML' });
          bot.sendMessage(chatId, part2, { parse_mode: 'HTML' });
        } catch (e: any) {
          log(`Error in /help: ${e.message}`, "telegram");
          bot.sendMessage(chatId, `❌ Error: ${e.message}`);
        }
        return;
      }

      if (msg.text?.length && msg.text.length >= 32 && msg.text.length <= 44 && !msg.text.includes(' ')) {
        if (!(await checkAiLane())) return;
        const mint = msg.text.trim();
        try {
          new PublicKey(mint);
          await sendTokenOverview(chatId, mint, undefined, msg.message_thread_id);
          return;
        } catch (e) {
          // Not a valid public key, ignore
        }
      }

      // Handle under construction commands
      if (msg.text?.startsWith('/buy') || msg.text?.startsWith('/sell') || msg.text === '/wallet' || msg.text === '/withdraw' || msg.text === '/settings' || msg.text === '/history') {
        if (msg.text === '/withdraw' && msg.reply_to_message) {
            // This is a reply to the withdraw message, but features are under construction
        }
        bot.sendMessage(chatId, "🚧 <b>Under Construction</b>\n\nTrading and wallet management features are currently under development. Please check back later.", { 
            parse_mode: 'HTML',
            message_thread_id: msg.message_thread_id
        });
        return;
      }

      if (msg.text === '/bind' || msg.text?.startsWith('/bind ')) {
        const parts = msg.text.split(' ');
        if (parts.length < 2) {
          bot.sendMessage(chatId, "❌ Usage: <code>/bind [market]</code>\nMarkets: <code>crypto, forex, ai</code>", { parse_mode: 'HTML' });
          return;
        }
        const lane = parts[1].toLowerCase();
        const market = (lane === 'forex') ? 'forex' : (lane === 'crypto' ? 'crypto' : (lane === 'ai' ? 'ai' : null));
        
        if (!market) {
          bot.sendMessage(chatId, "❌ Invalid market. Use <code>crypto</code>, <code>forex</code>, or <code>ai</code>.", { parse_mode: 'HTML' });
          return;
        }

        try {
          const groupIdStr = chatId.toString().trim();
          log(`Attempting to bind for group ${groupIdStr}, market: ${market}`, "telegram");

          // Check if binding exists for this group and market
          const existing = await db.select().from(groupBindings).where(
            and(
              eq(groupBindings.groupId, groupIdStr),
              eq(groupBindings.market, market)
            )
          ).limit(1);

          const cooldownKey = `cooldown_${market}`;
          const cooldownData = { [cooldownKey]: Date.now() + (10 * 60 * 1000) };

          if (existing.length > 0) {
            await db.update(groupBindings).set({
              topicId: msg.message_thread_id?.toString() || null,
              lane: market,
              data: JSON.stringify({ ...((typeof existing[0].data === 'string' ? JSON.parse(existing[0].data) : existing[0].data) || {}), ...cooldownData })
            }).where(eq(groupBindings.id, existing[0].id));
          } else {
            await db.insert(groupBindings).values({
              groupId: groupIdStr,
              topicId: msg.message_thread_id?.toString() || null,
              lane: market,
              market: market,
              data: JSON.stringify(cooldownData)
            });
          }

          let response = `✅ <b>Group Bound!</b>\nMarket: <code>${market}</code>\nTopic: <code>${msg.message_thread_id || 'Main'}</code>`;
          if (market !== 'ai') {
            response += `\n\n⏱ <i>Cooldown active: Scanning for new institutional setups in 10m...</i>`;
          }
          bot.sendMessage(chatId, response, { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
        } catch (dbErr: any) {
          log(`Bind error: ${dbErr.message}`, "telegram");
          bot.sendMessage(chatId, "❌ <b>Database error during binding.</b> Please ensure the bot is admin.", { parse_mode: 'HTML' });
        }
        return;
      }

      if (msg.text === '/unbind' || msg.text?.startsWith('/unbind ')) {
        const parts = msg.text.trim().split(/\s+/);
        const market = parts[1]?.toLowerCase();
        
        try {
          const groupIdStr = chatId.toString().trim();
          log(`Attempting to unbind for group ${groupIdStr}, market: ${market || 'ALL'}`, "telegram");
          
          if (market === 'crypto' || market === 'forex' || market === 'ai') {
            const deleted = await db.delete(groupBindings).where(
              and(
                or(
                  eq(groupBindings.groupId, groupIdStr),
                  eq(groupBindings.groupId, groupIdStr.replace("-100", "")),
                  eq(groupBindings.groupId, groupIdStr.includes("-100") ? groupIdStr : `-100${groupIdStr}`)
                ),
                eq(groupBindings.market, market)
              )
            ).returning();
            log(`Successfully unbound market ${market} for group ${groupIdStr}. Deleted rows: ${deleted.length}`, "telegram");
          } else {
            const deleted = await db.delete(groupBindings).where(
              or(
                eq(groupBindings.groupId, groupIdStr),
                eq(groupBindings.groupId, groupIdStr.replace("-100", "")),
                eq(groupBindings.groupId, groupIdStr.includes("-100") ? groupIdStr : `-100${groupIdStr}`)
              )
            ).returning();
            log(`Successfully unbound ALL markets for group ${groupIdStr}. Deleted rows: ${deleted.length}`, "telegram");
          }

          bot.sendMessage(chatId, `✅ <b>Group Unbound!</b>${market && (market === 'crypto' || market === 'forex' || market === 'ai') ? `\nMarket: <code>${market}</code>` : '\nAll markets unbound.'}`, { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
        } catch (dbErr: any) {
          log(`Unbind error: ${dbErr.message}`, "telegram");
          bot.sendMessage(chatId, "❌ <b>Database error during unbinding.</b>", { parse_mode: 'HTML' });
        }
        return;
      }

      if (msg.text === '/help' || msg.text === '/start' || msg.text === '/menu') {
        const helpMessage = `🏛️ <b>SMC Trading Bot - Command Guide</b>\n\n` +
          `<b>Core Commands:</b>\n` +
          `• /start or /menu - Access the main trading dashboard\n` +
          `• /bind [market] - Bind group to <code>crypto</code>, <code>forex</code>, or <code>ai</code>\n` +
          `• /analyze [pair] - Get a deep-dive institutional analysis\n` +
          `• /setup [pair] - Find a neutral breakout/pullback setup\n` +
          `• /ai [query] - Ask the AI specialist any trading question\n` +
          `• /unbind [market] - Unbind group from signals\n` +
          `• /settings - Configure security and trading preferences\n` +
          `• /history - View your recent trade history\n` +
          `• /withdraw - Withdraw SOL to an external wallet\n\n` +
          `<b>Advanced Features:</b>\n` +
          `• Send/Reply to a <b>Chart Image</b> with <code>/analyze</code> or <code>/setup</code> for visual AI analysis.\n` +
          `• Paste a <b>Solana Mint Address</b> to get a quick token overview and safety check.\n\n` +
          `<i>Note: Signals are posted automatically to bound groups every 15m. AI commands are restricted to the AI topic if bound.</i>`;
        const contactNote = `\n\nContact: @shiller_xxx or @FiftyOneP3rcent\nOwner: 6491714705 (can add admins and grant premium via /addadmin /removeadmin /premium)`;
        
        if (isPrivate) {
          if (msg.text === '/help') {
            bot.sendMessage(chatId, helpMessage + contactNote, { parse_mode: 'HTML' });
          } else if (msg.text === '/start') {
            const welcome = `👋 <b>Welcome to Coin Hunter Premium</b>\n\nJoin our community:\n• X: https://x.com/CoinHunterAIBot\n• Telegram: https://t.me/TheRealCoinHunterBeta\n\nYou have free access (2 analyzes/day). To unlock unlimited premium features, use the Subscribe buttons or /info for more.`;
            const keyboard = [[{ text: "Subscribe / Plans", callback_data: 'open_subscribe' }]];
            bot.sendMessage(chatId, welcome, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
          } else {
            await sendMainMenu(chatId, userId);
          }
        } else if (msg.text === '/help' || msg.text === '/start') {
          bot.sendMessage(chatId, helpMessage, { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
        }
        return;
      }

      if (msg.text === '/info') {
        const info = `📌 <b>Coin Hunter - Bot Features</b>\n\n` +
          `• Premium Institutional Signals (High-confluence SMC setups)\n` +
          `• AI-assisted analysis and chart image reasoning\n` +
          `• Token safety checks & market overviews\n` +
          `• Automated signal posting to bound groups\n\n` +
          `<b>Free Tier</b>: 2 analyzes/day + 2 AI requests/day.\n` +
          `<b>Premium</b>: Unlimited analyzes, priority signals, meme-coin calling in premium group, and early access features.\n\n` +
          `Subscription Plans:\n• $25/week • $50/2w • $75/3w • $100/month\n\n` +
          `To subscribe: press Subscribe -> pick a plan -> send SOL to the provided wallet and reply with the TX signature. We'll verify and activate your premium.`;
        bot.sendMessage(chatId, info + `\n\nContact: @shiller_xxx or @FiftyOneP3rcent\nOwner: 6491714705 (owner can add admins and grant premium with /addadmin /removeadmin /premium)`, { parse_mode: 'HTML' });
        return;
      }

      if (msg.text === '/settings') {
        const keyboard = [
          [{ text: "🔒 Security & MEV", callback_data: "settings_mev" }],
          [{ text: "🎯 Auto TP/SL", callback_data: "settings_tpsl" }],
          [{ text: "🔑 Wallet Export", callback_data: "settings_export" }],
          [{ text: "🔙 Back to Menu", callback_data: "main_menu" }]
        ];
        bot.sendMessage(chatId, "⚙️ <b>Bot Settings</b>\n\nConfigure your trading preferences below:", { 
          parse_mode: 'HTML', 
          reply_markup: { inline_keyboard: keyboard } 
        });
        return;
      }

      if (msg.text === '/history') {
        const trades = await storage.getTrades(userId);
        if (trades.length === 0) {
          bot.sendMessage(chatId, "📜 <b>Trade History</b>\n\nYou have no trade history.", { parse_mode: 'HTML' });
          return;
        }
        const msgHistory = `📜 <b>Trade History</b>\n\n` +
                   trades.slice(0, 10).map(t => `${t.status === 'completed' ? '✅' : '❌'} ${t.mint.slice(0, 8)}... - ${t.amountIn} SOL`).join('\n');
        bot.sendMessage(chatId, msgHistory, { parse_mode: 'HTML' });
        return;
      }

      if (msg.text === '/withdraw') {
        bot.sendMessage(chatId, "💰 <b>Withdraw SOL</b>\n\nPlease reply to this message with the Solana destination address:", { 
          parse_mode: 'HTML', 
          reply_markup: { force_reply: true } 
        });
        return;
      }

      if (msg.photo && (msg.caption?.startsWith('/analyze') || msg.caption?.startsWith('/setup'))) {
        if (!(await checkAiLane())) return;
        const parts = msg.caption.split(' ');
        const command = parts[0].replace('/', '');
        const pair = parts[1]?.toUpperCase();
        
        // Handle image analysis
        const photo = msg.photo[msg.photo.length - 1];
        const fileLink = await bot.getFileLink(photo.file_id);
        
        bot.sendMessage(chatId, `⏳ <b>Analyzing chart image for ${pair || 'detected pair'}...</b>`, { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
        
        const workerModule = await import("./signals-worker") as any;
        const aiModule = await import("./ai") as any;
        const worker = workerModule.default || workerModule;
        const ai = aiModule.default || aiModule;
        
        let targetPair: string | undefined = pair;
        if (!targetPair) {
          const detected = await ai.extractPairFromImage(fileLink);
          targetPair = detected || undefined;
        }
        
        if (!targetPair) {
          bot.sendMessage(chatId, "❌ <b>Could not detect trading pair from image.</b> Please provide it manually: <code>/analyze BTC/USDT</code>", { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
          return;
        }
        
        const sym = targetPair.includes('/') ? targetPair.split('/')[0].toUpperCase() : targetPair.toUpperCase();
        const forexSymbols = ['EUR', 'GBP', 'JPY', 'CHF', 'AUD', 'CAD', 'NZD', 'USD', 'XAU', 'XAG'];
        const isForex = forexSymbols.includes(sym) || (targetPair.includes('/') && forexSymbols.includes(targetPair.split('/')[1].toUpperCase()));
        const marketType = isForex ? "forex" : "crypto";

        const allowed = await checkAndConsumeUsage(msg.from!.id.toString(), 'analyze', chatId);
        if (!allowed) return;
        worker.runScanner(marketType, true, chatId.toString(), msg.message_thread_id?.toString(), targetPair, command as "analyze" | "setup", fileLink);
        return;
      }

      if (msg.text?.startsWith('/analyze') || msg.text?.startsWith('/setup')) {
        if (!(await checkAiLane())) return;
        const parts = msg.text.split(' ');
        const command = parts[0].replace('/', '');
        const pair = parts[1]?.toUpperCase();
        
        if (!pair) {
          bot.sendMessage(chatId, `❌ Please provide a pair, e.g. <code>/${command} BTC/USDT</code>`, { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
          return;
        }

        const feedbackMsg = command === 'setup' 
          ? `⏳ <b>Hang on while we generate a NEUTRAL setup for you...</b>`
          : `⏳ <b>Hang on while we perform a NEUTRAL analysis for you...</b>`;
          
        bot.sendMessage(chatId, feedbackMsg, { parse_mode: 'HTML', message_thread_id: msg.message_thread_id });
        const workerModule = await import("./signals-worker") as any;
        const worker = workerModule.default || workerModule;
        
        // Robust market type detection
        const forexSymbols = ['EUR', 'GBP', 'JPY', 'CHF', 'AUD', 'CAD', 'NZD', 'USD', 'XAU', 'XAG'];
        const symPrefix = pair.slice(0, 3);
        const isForex = forexSymbols.includes(symPrefix) || (pair.includes('/') && (forexSymbols.includes(pair.split('/')[0]) || forexSymbols.includes(pair.split('/')[1])));
        const marketType = isForex ? "forex" : "crypto";
        
        // Ensure pair has a slash for scanner consistency if it doesn't already
        let normalizedPair = pair;
        if (!pair.includes('/') && pair.length >= 6) {
          normalizedPair = `${pair.slice(0, pair.length - 4)}/${pair.slice(pair.length - 4)}`;
        }
        
        log(`Manual command: ${command} for ${normalizedPair} (${marketType})`, "telegram");
        const allowed = await checkAndConsumeUsage(msg.from!.id.toString(), 'analyze', chatId);
        if (!allowed) return;
        worker.runScanner(marketType, true, chatId.toString(), msg.message_thread_id?.toString(), normalizedPair, command as "analyze" | "setup");
        return;
      }

      if (msg.reply_to_message && msg.text) {
        const replyText = msg.reply_to_message.text || "";
        if (replyText.includes("Please paste the token's Solana contract address (Mint)")) {
          const mint = msg.text.trim();
          try {
            new PublicKey(mint);
            await sendTokenOverview(chatId, mint);
          } catch (e) {
            bot.sendMessage(chatId, "❌ <b>Invalid Solana address.</b> Please try again.", { parse_mode: 'HTML' });
          }
        } else if (replyText.includes("Please enter the token's contract address")) {
          await sendTokenOverview(chatId, msg.text.trim());
        } else if (replyText.includes("Please reply to this message with the Solana destination address")) {
          const address = msg.text.trim();
          try {
            new PublicKey(address);
            bot.sendMessage(chatId, `💰 <b>Withdrawal</b>\nAddress: <code>${address}</code>\n\nPlease reply to this message with the amount of SOL to withdraw:`, { 
              parse_mode: 'HTML', 
              reply_markup: { force_reply: true } 
            });
          } catch (e) {
            bot.sendMessage(chatId, "❌ <b>Invalid Solana Address.</b> Please try again.", { parse_mode: 'HTML' });
          }
        } else if (replyText.includes("Please reply to this message with the amount of SOL to withdraw")) {
          const amount = parseFloat(msg.text);
          const addressMatch = replyText.match(/Address: <code>(.*?)<\/code>/);
          if (!isNaN(amount) && addressMatch) {
            const address = addressMatch[1];
            try {
              const activeWallet = await storage.getActiveWallet(userId);
              if (!activeWallet) throw new Error("No active wallet.");
              
              const connection = new Connection(rpcUrl, "confirmed");
              const balance = await connection.getBalance(new PublicKey(activeWallet.publicKey));
              const lamports = Math.floor(amount * 1e9);
              
              if (balance < lamports + 5000) throw new Error("Insufficient balance for withdrawal + fees.");
              
              const transaction = new Transaction().add(
                SystemProgram.transfer({
                  fromPubkey: new PublicKey(activeWallet.publicKey),
                  toPubkey: new PublicKey(address),
                  lamports: lamports,
                })
              );
              
              const keypair = Keypair.fromSecretKey(bs58.decode(activeWallet.privateKey));
              const signature = await connection.sendTransaction(transaction, [keypair]);
              await connection.confirmTransaction(signature);
              
              // Update balance immediately after withdrawal
              const newBal = await connection.getBalance(new PublicKey(activeWallet.publicKey));
              await storage.updateWalletBalance(activeWallet.id, (newBal / 1e9).toFixed(3));

              bot.sendMessage(chatId, `✅ <b>Withdrawal Successful!</b>\n\nTX: <a href="https://solscan.io/tx/${signature}">${signature.slice(0,8)}...</a>`, { parse_mode: 'HTML' });
            } catch (e: any) {
              bot.sendMessage(chatId, `❌ <b>Withdrawal Failed:</b> ${e.message}`, { parse_mode: 'HTML' });
            }
          }
        }
        // Handle subscription tx signature reply
        else if (replyText.includes("Please send the transaction signature")) {
          const sig = msg.text.trim();
          const pending = subscriptionPending[userId];
          if (!pending) {
            bot.sendMessage(chatId, "❌ No pending subscription found. Please choose a plan first.");
            return;
          }
          const ok = await verifyTransactionAndGrant(userId, sig, pending.lamports, pending.days, chatId);
          if (ok) delete subscriptionPending[userId];
          return;
        }
      }

    } catch (e: any) {
      // Log full error details for debugging
      const errorMsg = e instanceof Error ? e.message : String(e);
      const errorStack = e instanceof Error ? e.stack : '';
      log(`Message error: ${errorMsg}${errorStack ? ` \n${errorStack}` : ''}`, "telegram");
    }
  });

  bot.on('callback_query', async (query) => {
    const chatId = query.message?.chat.id;
    const userId = query.from.id.toString();
    const data = query.data;

    if (!chatId || !data) return;

    try {
      if (data === 'open_subscribe') {
        const keyboard = [
          [{ text: "$25 / 1w", callback_data: `subscribe:25:7` }, { text: "$50 / 2w", callback_data: `subscribe:50:14` }],
          [{ text: "$75 / 3w", callback_data: `subscribe:75:21` }, { text: "$100 / 1m", callback_data: `subscribe:100:30` }]
        ];
        await bot.sendMessage(chatId, "Choose a subscription tier:", { reply_markup: { inline_keyboard: keyboard } });
        bot.answerCallbackQuery(query.id);
        return;
      }

      if (data === "main_menu") {
        await sendMainMenu(chatId, userId, query.message?.message_id);
      } else if (data === "main_menu_refresh") {
        await sendMainMenu(chatId, userId, query.message?.message_id);
        bot.answerCallbackQuery(query.id, { text: "Refreshed!" });
      } else if (data === "under_construction") {
        bot.answerCallbackQuery(query.id, { text: "🚧 Under Construction" });
        bot.sendMessage(chatId, "🚧 <b>Under Construction</b>\n\nThis feature is currently under development. Please check back later.", { parse_mode: 'HTML' });
      } else if (data === "menu_settings") {
        const keyboard = [
          [{ text: "🔒 Security & MEV", callback_data: "settings_mev" }],
          [{ text: "🎯 Auto TP/SL", callback_data: "settings_tpsl" }],
          [{ text: "🔑 Wallet Export", callback_data: "settings_export" }],
          [{ text: "🔙 Back to Menu", callback_data: "main_menu" }]
        ];
        try {
          await bot.editMessageText("⚙️ <b>Bot Settings</b>\n\nConfigure your trading preferences below:", { 
            chat_id: chatId, 
            message_id: query.message?.message_id,
            parse_mode: 'HTML', 
            reply_markup: { inline_keyboard: keyboard } 
          });
        } catch (e: any) {
          if (!e.message.includes("message is not modified")) throw e;
        }
      } else if (data === "menu_history") {
        const trades = await storage.getTrades(userId);
        if (trades.length === 0) {
          bot.sendMessage(chatId, "📜 <b>Trade History</b>\n\nYou have no trade history.", { parse_mode: 'HTML' });
        } else {
          const msgHistory = `📜 <b>Trade History</b>\n\n` +
                     trades.slice(0, 10).map(t => `${t.status === 'completed' ? '✅' : '❌'} ${t.mint.slice(0, 8)}... - ${t.amountIn} SOL`).join('\n');
          bot.sendMessage(chatId, msgHistory, { parse_mode: 'HTML' });
        }
        bot.answerCallbackQuery(query.id);
      } else if (data.startsWith('admin_remove:')) {
        const caller = query.from.id.toString();
        const OWNER_ID = '6491714705';
        if (caller !== OWNER_ID) {
          bot.answerCallbackQuery(query.id, { text: 'Only owner can remove admins.' });
          return;
        }
        const target = data.split(':')[1];
        try {
          await storage.removeAdmin(target);
          bot.answerCallbackQuery(query.id, { text: `Removed admin ${target}` });
          try {
            await bot.editMessageText(`Admin ${target} removed by owner.`, { chat_id: query.message?.chat.id, message_id: query.message?.message_id });
          } catch (e) {}
        } catch (e: any) {
          bot.answerCallbackQuery(query.id, { text: `Failed to remove admin: ${e.message}` });
        }
        return;
      } else if (data.startsWith('refresh_overview_')) {
        const mint = data.replace('refresh_overview_', '');
        await sendTokenOverview(chatId, mint, query.message?.message_id);
        bot.answerCallbackQuery(query.id, { text: "Refreshed!" });
      } else if (data.startsWith('ai_analyze_')) {
        const mint = data.replace('ai_analyze_', '');
        await executeAiReasoning(chatId, mint);
        bot.answerCallbackQuery(query.id);
      } else if (data === "menu_withdraw") {
        bot.sendMessage(chatId, "💰 <b>Withdraw SOL</b>\n\nPlease reply to this message with the Solana destination address:", { 
          parse_mode: 'HTML', 
          reply_markup: { force_reply: true } 
        });
        bot.answerCallbackQuery(query.id);
      }
      else if (data.startsWith('subscribe:')) {
        // subscribe:<usd>:<days>
        const parts = data.split(":");
        const usd = Number(parts[1]);
        const days = Number(parts[2]);
        const wallet = PAYMENT_WALLET || '<not-configured>';
        try {
          const { sol, lamports } = await getSolForUsd(usd);
          // generate short memo reference to include in user's tx for reliable verification
          const ref = Math.random().toString(36).slice(2, 9).toUpperCase();
          const msg = `To subscribe for $${usd} (${days} days), please send approximately <b>${sol} SOL</b> (~$${usd}) to the following wallet:\n\n<code>${wallet}</code>\n\nIMPORTANT: Include this reference in the transaction memo field exactly: <b>${ref}</b>\n\nAfter sending, reply to this message with the transaction signature (tx id) so we can verify and activate your premium. We will verify the amount (±0.5%) and the memo.`;
          await bot.sendMessage(chatId, msg, { parse_mode: 'HTML', reply_markup: { force_reply: true } });
          // record pending subscription with required lamports and memo reference
          subscriptionPending[userId] = { lamports, days, ref };
          bot.answerCallbackQuery(query.id, { text: `Subscription flow started for $${usd} (~${sol} SOL). Memo: ${ref}` });
        } catch (e: any) {
          bot.sendMessage(chatId, `❌ Failed to fetch SOL price. Please try again later.`);
          bot.answerCallbackQuery(query.id, { text: `Price oracle error` });
        }
        return;
      }
    } catch (e: any) {
      log(`Callback error: ${e.message}`, "telegram");
    }
  });

  log("Telegram bot setup complete.", "telegram");
}
